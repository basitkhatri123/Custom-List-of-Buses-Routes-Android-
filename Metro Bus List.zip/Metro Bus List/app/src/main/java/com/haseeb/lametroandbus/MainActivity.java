
package com.haseeb.lametroandbus;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.haseeb.lametroandbus.Adapters.CustomAdapter;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ListView listView ;
    private ArrayList<BusRoute> busRouteArrayList;
    private CustomAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        busRouteArrayList = new ArrayList<>();
        busRouteArrayList.add(new BusRoute("04", "Downtown LA - Westwood"));
        busRouteArrayList.add(new BusRoute("10", "Downtown LA - Santa Moni Santa"));
        busRouteArrayList.add(new BusRoute("14", "W Holly "));
        busRouteArrayList.add(new BusRoute("16", "Downtown LA - "));
        busRouteArrayList.add(new BusRoute("17", "Downtown LA -  Monica Via Santa"));
        busRouteArrayList.add(new BusRoute("18", " LA - Santa  Via Santa"));
        busRouteArrayList.add(new BusRoute("20", "Downtown LA - Sanica Via Santa"));
        busRouteArrayList.add(new BusRoute("28", "DowntoMonica Via Santa"));
        busRouteArrayList.add(new BusRoute("30", "Wn LA - Santa Monica Via Santa"));
        busRouteArrayList.add(new BusRoute("04", "Downtown LA - Westwood"));
        busRouteArrayList.add(new BusRoute("10", "Downtown LA - Santa Moni Santa"));
        busRouteArrayList.add(new BusRoute("14", "W Holly "));
        busRouteArrayList.add(new BusRoute("16", "Downtown LA - "));
        busRouteArrayList.add(new BusRoute("17", "Downtown LA -  Monica Via Santa"));
        busRouteArrayList.add(new BusRoute("18", "Downtown LA - Santa  Via Santa"));
        busRouteArrayList.add(new BusRoute("20", "Downtown LA - Sanica Via Santa"));
        busRouteArrayList.add(new BusRoute("28", "DowntoMonica Via Santa"));
        busRouteArrayList.add(new BusRoute("30", "Wn LA - Santa Monica Via Santa"));

        listView = (ListView)findViewById(R.id.listViewID);

        adapter = new CustomAdapter(busRouteArrayList, getApplicationContext());
        listView.setAdapter(adapter);




    }
}


