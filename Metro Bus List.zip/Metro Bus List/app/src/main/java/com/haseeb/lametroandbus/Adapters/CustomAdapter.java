
package com.haseeb.lametroandbus.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.haseeb.lametroandbus.BusRoute;
import com.haseeb.lametroandbus.MainActivity;
import com.haseeb.lametroandbus.R;

import java.util.ArrayList;
import java.util.List;

public class CustomAdapter extends ArrayAdapter<BusRoute>
{
Context context;
private ArrayList<BusRoute> busRoutes;

    public CustomAdapter(ArrayList<BusRoute> busRoutes , Context context ) {
        super(context,R.layout.bus_route_listview,busRoutes);
        this.context = context;
        this.busRoutes = busRoutes;
    }

    @Override
    public View getView(int position,  View convertView, ViewGroup parent) {

        BusRoute busRoute = getItem(position);
        convertView = LayoutInflater.from(context).inflate(R.layout.bus_route_listview, parent,false);
        TextView textView = convertView.findViewById(R.id.numberTextView);
        textView.setText(busRoute.getRouteName() + "");
        TextView textView1 = convertView.findViewById(R.id.busRouteTextViewID);
        textView1.setText(busRoute.getRouteDetail() + "");
        return convertView;
    }

}