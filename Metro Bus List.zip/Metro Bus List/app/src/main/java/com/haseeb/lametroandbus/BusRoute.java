package com.haseeb.lametroandbus;

public class BusRoute{
    private String routeName;
    private String routeDetail;

    public BusRoute(String routeName, String routeDetail) {
        this.routeName = routeName;
        this.routeDetail = routeDetail;
    }
    public String getRouteName() {
        return routeName;
    }
    public void setRouteName(String routeName){
        this.routeName = routeName;
    }

    public String getRouteDetail() {
        return routeDetail;
    }

    public void setRouteDetail(String routeDetail){
        this.routeDetail = routeDetail;
    }
}

